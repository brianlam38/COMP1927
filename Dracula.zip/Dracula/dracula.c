// dracula.c
// Implementation of your "Fury of Dracula" Dracula AI

#include <stdlib.h>
#include <stdio.h>
#include "Game.h"
#include "DracView.h"

void decideDraculaMove(DracView gameState)
{
	// TODO ...
	// Replace the line below by something better
	registerBestPlay("CD","Mwuhahahaha");
}

// Hello world